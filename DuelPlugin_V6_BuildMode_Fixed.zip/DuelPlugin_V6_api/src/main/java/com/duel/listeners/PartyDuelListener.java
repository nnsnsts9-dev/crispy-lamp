package com.duel.listeners;

import com.duel.DuelPlugin;
import com.duel.models.PartyDuelSession;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerRespawnEvent;

public class PartyDuelListener implements Listener {

    private final DuelPlugin plugin;

    public PartyDuelListener(DuelPlugin plugin) {
        this.plugin = plugin;
    }

    // ──────────────────────────────────────────
    //  موت → spectator (أو نهاية مباراة)
    // ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        Player dead = event.getEntity();
        if (!plugin.getPartyDuelManager().isInPartyDuel(dead)) return;

        PartyDuelSession session = plugin.getPartyDuelManager().getSession(dead);
        if (session == null || session.getState() != PartyDuelSession.State.FIGHTING) return;

        // إلغاء الـ drops ورسالة الموت
        event.setDeathMessage(null);
        event.getDrops().clear();
        event.setDroppedExp(0);

        // سجّل الموت في الجلسة
        plugin.getPartyDuelManager().onPlayerDeath(dead);
    }

    // ──────────────────────────────────────────
    //  Respawn → ابقِه spectator في نفس العالم
    // ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onRespawn(PlayerRespawnEvent event) {
        Player p = event.getPlayer();
        PartyDuelSession session = plugin.getPartyDuelManager().getSession(p);
        if (session == null) return;

        // اجعله يرسبن في نفس العالم بدل السبون الافتراضي
        org.bukkit.World duelWorld = org.bukkit.Bukkit.getWorld(session.getCopiedWorldName());
        if (duelWorld != null) {
            event.setRespawnLocation(duelWorld.getSpawnLocation());
        }

        // بعد tick واحد — حوّله spectator
        plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
            if (p.isOnline()) {
                p.setGameMode(GameMode.SPECTATOR);
            }
        }, 1L);
    }

    // ──────────────────────────────────────────
    //  PvP — اسمح بالضرر داخل نفس الجلسة فقط
    // ──────────────────────────────────────────

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity()  instanceof Player victim))   return;
        if (!(event.getDamager() instanceof Player attacker)) return;

        boolean aInPartyDuel = plugin.getPartyDuelManager().isInPartyDuel(attacker);
        boolean vInPartyDuel = plugin.getPartyDuelManager().isInPartyDuel(victim);

        // لا أحد في party duel — اتركها للـ DuelListener العادي
        if (!aInPartyDuel && !vInPartyDuel) return;

        // أحدهم في party duel والثاني لا — الغِ
        if (aInPartyDuel != vInPartyDuel) {
            event.setCancelled(true);
            return;
        }

        // كلاهما في party duel — يجب أن يكونا في نفس الجلسة
        PartyDuelSession aSession = plugin.getPartyDuelManager().getSession(attacker);
        PartyDuelSession vSession = plugin.getPartyDuelManager().getSession(victim);

        if (aSession == null || !aSession.equals(vSession)) {
            event.setCancelled(true);
            return;
        }

        // لا يجوز الضرب بين أعضاء نفس الفريق
        if (aSession.getTeamOf(attacker) == aSession.getTeamOf(victim)) {
            event.setCancelled(true);
            return;
        }

        // هل الجلسة في مرحلة القتال؟
        if (aSession.getState() != PartyDuelSession.State.FIGHTING) {
            event.setCancelled(true);
            return;
        }

        // هل الضحية لا تزال حية؟
        if (!aSession.isAlive(victim)) {
            event.setCancelled(true);
            return;
        }

        // كل الشروط مرت — اسمح بالضرر
    }
}
