package com.duel.managers;

import com.duel.DuelPlugin;
import com.duel.models.Arena;
import com.duel.utils.ItemUtils;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.*;

/**
 * Multi-step arena setup:
 * 1. WORLD_COUNT   — how many worlds?
 * 2. WORLD_NAMES   — type each world name
 * 3. WORLD_SETTINGS — GUI: block-break / block-place / difficulty
 * 4. SPAWN_SELECTION — golden axe to set P1/P2 spawns per world
 */
public class ConversationManager implements Listener {

    private final DuelPlugin plugin;

    enum Step { WORLD_COUNT, WORLD_NAMES, WORLD_SETTINGS, SPAWN_SELECTION }

    private final Map<UUID, Step>         step            = new HashMap<>();
    private final Map<UUID, Arena>        arenaMap        = new HashMap<>();
    private final Map<UUID, Integer>      worldCount      = new HashMap<>();
    private final Map<UUID, List<String>> collectedWorlds = new HashMap<>();
    private final Map<UUID, Integer>      worldIndex      = new HashMap<>();
    private final Map<UUID, Integer>      spawnIndex      = new HashMap<>();

    // Tracks which admins have the settings GUI open
    private final Map<UUID, Inventory>    settingsGuiMap  = new HashMap<>();

    // ── Settings GUI slots ────────────────────────────────────────────────
    private static final int SLOT_BREAK_YES  =  11;
    private static final int SLOT_BREAK_NO   =  13;
    private static final int SLOT_BUILD_YES  =  20;
    private static final int SLOT_BUILD_NO   =  22;
    private static final int SLOT_DIFF_EASY  =  29;
    private static final int SLOT_DIFF_NORM  =  31;
    private static final int SLOT_DIFF_HARD  =  33;
    private static final int SLOT_CONFIRM    =  49;

    public ConversationManager(DuelPlugin plugin) {
        this.plugin = plugin;
        plugin.getServer().getPluginManager().registerEvents(this, plugin);
    }

    // ─────────────────────────────────────────
    //  Entry point
    // ─────────────────────────────────────────

    public void startWorldSetup(Player admin, Arena arena) {
        arenaMap.put(admin.getUniqueId(), arena);
        step.put(admin.getUniqueId(), Step.WORLD_COUNT);
        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&b⚙ Arena Setup &8— &e" + arena.getId()));
        admin.sendMessage(color("&7How many worlds does this arena have?"));
        admin.sendMessage(color("&8(type a number in chat)"));
    }

    // ─────────────────────────────────────────
    //  Chat listener
    // ─────────────────────────────────────────

    @EventHandler
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        UUID uid = player.getUniqueId();
        if (!step.containsKey(uid)) return;
        event.setCancelled(true);
        String msg = event.getMessage().trim();
        Step current = step.get(uid);
        if (current == Step.WORLD_COUNT)  handleWorldCount(player, msg);
        else if (current == Step.WORLD_NAMES) handleWorldName(player, msg);
    }

    private void handleWorldCount(Player admin, String msg) {
        int count;
        try {
            count = Integer.parseInt(msg);
            if (count <= 0 || count > 20) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            admin.sendMessage(color("&cInvalid number! Please enter a number between 1 and 20."));
            return;
        }
        worldCount.put(admin.getUniqueId(), count);
        collectedWorlds.put(admin.getUniqueId(), new ArrayList<>());
        step.put(admin.getUniqueId(), Step.WORLD_NAMES);
        admin.sendMessage(color("&aGreat! Now type the name of world &e#1&a:"));
    }

    private void handleWorldName(Player admin, String msg) {
        UUID uid = admin.getUniqueId();
        List<String> worlds = collectedWorlds.get(uid);
        int total = worldCount.get(uid);
        World w = Bukkit.getWorld(msg);
        if (w == null) {
            admin.sendMessage(color("&cWorld '&e" + msg + "&c' not found! Make sure it's loaded with Multiverse."));
            admin.sendMessage(color("&7Try again:"));
            return;
        }
        worlds.add(msg);
        int next = worlds.size() + 1;
        if (worlds.size() < total) {
            admin.sendMessage(color("&a✔ Added world &e" + msg + "&a. Now type world &e#" + next + "&a:"));
        } else {
            Arena arena = arenaMap.get(uid);
            arena.getWorlds().clear();
            arena.getWorlds().addAll(worlds);
            admin.sendMessage(color("&a✔ All " + total + " worlds saved!"));
            step.put(uid, Step.WORLD_SETTINGS);
            // Open settings GUI on main thread
            Bukkit.getScheduler().runTask(plugin, () -> openSettingsGui(admin));
        }
    }

    // ─────────────────────────────────────────
    //  World Settings GUI
    // ─────────────────────────────────────────

    private void openSettingsGui(Player admin) {
        Arena arena = arenaMap.get(admin.getUniqueId());

        Inventory inv = Bukkit.createInventory(
                new SettingsHolder(),
                54,
                Component.text("⚙ World Settings — " + arena.getId())
                        .color(NamedTextColor.GOLD)
                        .decoration(TextDecoration.BOLD, false)
        );

        // Fill border
        ItemStack gray = filler(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 54; i++) inv.setItem(i, gray);

        // ── Block breaking row ──────────────────────────────────────────
        inv.setItem(10, label(Material.IRON_PICKAXE,
                "§e§lCan Players Break Blocks?",
                "§7Can players break blocks?"));
        inv.setItem(SLOT_BREAK_YES, choice(Material.LIME_DYE,    "§a§l✔  Yes", "§7Players can break blocks"));
        inv.setItem(SLOT_BREAK_NO,  choice(Material.RED_DYE,     "§c§l✘  No",  "§7Block breaking is disabled"));

        // ── Block placing row ───────────────────────────────────────────
        inv.setItem(19, label(Material.OAK_PLANKS,
                "§e§lCan Players Place Blocks?",
                "§7Can players place blocks?"));
        inv.setItem(SLOT_BUILD_YES, choice(Material.LIME_DYE,    "§a§l✔  Yes", "§7Players can place blocks"));
        inv.setItem(SLOT_BUILD_NO,  choice(Material.RED_DYE,     "§c§l✘  No",  "§7Block placing is disabled"));

        // ── Difficulty row ──────────────────────────────────────────────
        inv.setItem(28, label(Material.BARRIER,
                "§e§lWorld Difficulty",
                "§7World difficulty"));
        inv.setItem(SLOT_DIFF_EASY, choice(Material.GREEN_STAINED_GLASS,  "§a§l  Easy",   "§7Peaceful mobs, less damage"));
        inv.setItem(SLOT_DIFF_NORM, choice(Material.YELLOW_STAINED_GLASS, "§e§l  Normal", "§7Standard gameplay"));
        inv.setItem(SLOT_DIFF_HARD, choice(Material.RED_STAINED_GLASS,    "§c§l  Hard",   "§7Increased mob damage & hunger"));

        // ── Confirm button ──────────────────────────────────────────────
        inv.setItem(SLOT_CONFIRM, buildGlow(Material.LIME_DYE,
                "§a§l✔  Confirm & Continue",
                "§7Save settings and proceed to spawn selection"));

        // Default selections highlighted
        highlightSelection(inv, SLOT_BREAK_NO,  SLOT_BREAK_YES,  SLOT_BREAK_NO);
        highlightSelection(inv, SLOT_BUILD_NO,  SLOT_BUILD_YES,  SLOT_BUILD_NO);
        highlightSelection(inv, SLOT_DIFF_NORM, SLOT_DIFF_EASY,  SLOT_DIFF_NORM, SLOT_DIFF_HARD);

        settingsGuiMap.put(admin.getUniqueId(), inv);
        admin.openInventory(inv);

        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&b⚙ Choose world settings, then click Confirm."));
    }

    /** Tracks current selections per player: "break"→slot, "build"→slot, "diff"→slot */
    private final Map<UUID, Map<String, Integer>> selections = new HashMap<>();

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onSettingsClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player admin)) return;
        UUID uid = admin.getUniqueId();
        if (!settingsGuiMap.containsKey(uid)) return;
        if (!(event.getInventory().getHolder() instanceof SettingsHolder)) return;

        event.setCancelled(true);
        int slot = event.getRawSlot();
        Inventory inv = settingsGuiMap.get(uid);
        Map<String, Integer> sel = selections.computeIfAbsent(uid, k -> new HashMap<>());

        if (slot == SLOT_BREAK_YES || slot == SLOT_BREAK_NO) {
            sel.put("break", slot);
            highlightSelection(inv, slot, SLOT_BREAK_YES, SLOT_BREAK_NO);
            playClick(admin);
        } else if (slot == SLOT_BUILD_YES || slot == SLOT_BUILD_NO) {
            sel.put("build", slot);
            highlightSelection(inv, slot, SLOT_BUILD_YES, SLOT_BUILD_NO);
            playClick(admin);
        } else if (slot == SLOT_DIFF_EASY || slot == SLOT_DIFF_NORM || slot == SLOT_DIFF_HARD) {
            sel.put("diff", slot);
            highlightSelection(inv, slot, SLOT_DIFF_EASY, SLOT_DIFF_NORM, SLOT_DIFF_HARD);
            playClick(admin);
        } else if (slot == SLOT_CONFIRM) {
            confirmSettings(admin, inv, sel);
        }
    }

    @EventHandler
    public void onSettingsClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player admin)) return;
        UUID uid = admin.getUniqueId();
        if (!settingsGuiMap.containsKey(uid)) return;
        if (!(event.getInventory().getHolder() instanceof SettingsHolder)) return;

        // If closed without confirming, reopen after 1 tick
        if (step.containsKey(uid) && step.get(uid) == Step.WORLD_SETTINGS) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (step.containsKey(uid) && step.get(uid) == Step.WORLD_SETTINGS) {
                    admin.sendMessage(color("&cPlease choose the world settings before continuing!"));
                    admin.openInventory(settingsGuiMap.get(uid));
                }
            }, 2L);
        }
    }

    private void confirmSettings(Player admin, Inventory inv, Map<String, Integer> sel) {
        UUID uid = admin.getUniqueId();
        Arena arena = arenaMap.get(uid);

        boolean breaking = sel.getOrDefault("break", SLOT_BREAK_NO) == SLOT_BREAK_YES;
        boolean building = sel.getOrDefault("build", SLOT_BUILD_NO) == SLOT_BUILD_YES;
        String diff = switch (sel.getOrDefault("diff", SLOT_DIFF_NORM)) {
            case SLOT_DIFF_EASY -> "easy";
            case SLOT_DIFF_HARD -> "hard";
            default             -> "normal";
        };

        arena.setAllowBreaking(breaking);
        arena.setAllowBuilding(building);
        arena.setDifficulty(diff);

        settingsGuiMap.remove(uid);
        selections.remove(uid);
        step.put(uid, Step.SPAWN_SELECTION);
        worldIndex.put(uid, 0);
        spawnIndex.put(uid, 0);

        admin.closeInventory();
        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&a✔ World settings saved:"));
        admin.sendMessage(color("&7Breaking: " + (breaking ? "&aYes" : "&cNo")
                + "  &7Building: " + (building ? "&aYes" : "&cNo")
                + "  &7Difficulty: &e" + diff));
        admin.sendMessage(color("&bNow we will set the spawn points."));

        Bukkit.getScheduler().runTaskLater(plugin, () -> startSpawnSelection(admin), 5L);
    }

    // ─────────────────────────────────────────
    //  Spawn selection
    // ─────────────────────────────────────────

    private void startSpawnSelection(Player admin) {
        UUID uid = admin.getUniqueId();
        Arena arena = arenaMap.get(uid);
        List<String> worlds = collectedWorlds.get(uid);
        int wIdx = worldIndex.get(uid);
        int sIdx = spawnIndex.getOrDefault(uid, 0);

        if (wIdx >= worlds.size()) {
            finishSetup(admin);
            return;
        }

        String worldName = worlds.get(wIdx);
        World world = Bukkit.getWorld(worldName);
        String playerLabel = sIdx == 0 ? "&aP1 &7(Player 1)" : "&cP2 &7(Player 2)";

        admin.teleport(world.getSpawnLocation());
        admin.getInventory().clear();
        admin.getInventory().addItem(ItemUtils.getSpawnAxe(worldName));
        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&bWorld: &e" + worldName + " &8(" + (wIdx + 1) + "/" + worlds.size() + ")"
                + " &8— Spawn " + playerLabel));
        admin.sendMessage(color("&7Stand where you want the &e" + (sIdx == 0 ? "P1" : "P2")
                + " spawn&7 and &aright-click the golden axe&7."));
    }

    @EventHandler
    public void onAxeClick(PlayerInteractEvent event) {
        Player admin = event.getPlayer();
        UUID uid = admin.getUniqueId();
        if (!step.containsKey(uid) || step.get(uid) != Step.SPAWN_SELECTION) return;
        if (event.getHand() != EquipmentSlot.HAND) return;
        var item = admin.getInventory().getItemInMainHand();
        if (item.getType() != org.bukkit.Material.GOLDEN_AXE) return;
        event.setCancelled(true);

        Arena arena = arenaMap.get(uid);
        List<String> worlds = collectedWorlds.get(uid);
        int idx = worldIndex.get(uid);
        String worldName = worlds.get(idx);
        int sIdx = spawnIndex.getOrDefault(uid, 0);
        String playerLabel = sIdx == 0 ? "P1" : "P2";

        arena.addSpawn(worldName, admin.getLocation().clone());
        admin.getInventory().removeItem(item);
        admin.sendMessage(color("&a✔ " + playerLabel + " spawn set for world &e" + worldName + "&a!"));

        if (sIdx == 0) {
            spawnIndex.put(uid, 1);
            Bukkit.getScheduler().runTaskLater(plugin, () -> startSpawnSelection(admin), 5L);
        } else {
            spawnIndex.put(uid, 0);
            worldIndex.put(uid, idx + 1);
            Bukkit.getScheduler().runTaskLater(plugin, () -> startSpawnSelection(admin), 10L);
        }
    }

    // ─────────────────────────────────────────
    //  Finish
    // ─────────────────────────────────────────

    private void finishSetup(Player admin) {
        UUID uid = admin.getUniqueId();
        Arena arena = arenaMap.get(uid);
        plugin.getArenaManager().saveArena(arena);
        // Apply difficulty to all worlds now
        applyWorldSettings(arena);
        cleanup(uid);

        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
        admin.sendMessage(color("&a✔✔ Arena &e" + arena.getId() + " &ahas been fully configured!"));
        admin.sendMessage(color("&7Worlds: &f" + arena.getWorlds().size()
                + " &7| Spawns: &f" + arena.getSpawnPoints().size()));
        admin.sendMessage(color("&7Breaking: &f" + (arena.isAllowBreaking() ? "Yes" : "No")
                + " &7| Building: &f" + (arena.isAllowBuilding() ? "Yes" : "No")
                + " &7| Difficulty: &f" + arena.getDifficulty()));
        admin.sendMessage(color("&7Use &f/GUI KIT " + arena.getId() + " &7to set the kit."));
        admin.sendMessage(color("&7━━━━━━━━━━━━━━━━━━━━━━━━"));
    }

    private void applyWorldSettings(Arena arena) {
        org.bukkit.Difficulty diff = switch (arena.getDifficulty()) {
            case "easy" -> org.bukkit.Difficulty.EASY;
            case "hard" -> org.bukkit.Difficulty.HARD;
            default     -> org.bukkit.Difficulty.NORMAL;
        };
        for (String wName : arena.getWorlds()) {
            World w = Bukkit.getWorld(wName);
            if (w == null) continue;
            w.setDifficulty(diff);
            // Game rules for block breaking/placing
            w.setGameRule(org.bukkit.GameRule.DO_TILE_DROPS, arena.isAllowBreaking());
        }
    }

    private void cleanup(UUID uid) {
        step.remove(uid);
        arenaMap.remove(uid);
        worldCount.remove(uid);
        collectedWorlds.remove(uid);
        worldIndex.remove(uid);
        spawnIndex.remove(uid);
        settingsGuiMap.remove(uid);
        selections.remove(uid);
    }

    public boolean isInConversation(Player player) {
        return step.containsKey(player.getUniqueId());
    }

    // ─────────────────────────────────────────
    //  GUI helpers
    // ─────────────────────────────────────────

    /** Marks selected slot with glowing enchant effect, deselects others */
    private void highlightSelection(Inventory inv, int selected, int... group) {
        for (int slot : group) {
            ItemStack item = inv.getItem(slot);
            if (item == null) continue;
            ItemMeta meta = item.getItemMeta();
            if (meta == null) continue;
            if (slot == selected) {
                meta.addEnchant(org.bukkit.enchantments.Enchantment.LUCK, 1, true);
                meta.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
            } else {
                meta.removeEnchant(org.bukkit.enchantments.Enchantment.LUCK);
            }
            item.setItemMeta(meta);
        }
    }

    private ItemStack filler(Material mat, String name) {
        ItemStack i = new ItemStack(mat);
        ItemMeta m = i.getItemMeta();
        m.displayName(Component.text(name));
        i.setItemMeta(m);
        return i;
    }

    private ItemStack label(Material mat, String title, String sub) {
        ItemStack i = new ItemStack(mat);
        ItemMeta m = i.getItemMeta();
        m.displayName(Component.text(title));
        m.lore(List.of(Component.text(sub)));
        m.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ATTRIBUTES,
                       org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS);
        i.setItemMeta(m);
        return i;
    }

    private ItemStack choice(Material mat, String title, String lore) {
        ItemStack i = new ItemStack(mat);
        ItemMeta m = i.getItemMeta();
        m.displayName(Component.text(title));
        m.lore(List.of(Component.text(lore)));
        m.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ATTRIBUTES);
        i.setItemMeta(m);
        return i;
    }

    private ItemStack buildGlow(Material mat, String title, String lore) {
        ItemStack i = new ItemStack(mat);
        ItemMeta m = i.getItemMeta();
        m.displayName(Component.text(title));
        m.lore(List.of(Component.text(lore)));
        m.addEnchant(org.bukkit.enchantments.Enchantment.LUCK, 1, true);
        m.addItemFlags(org.bukkit.inventory.ItemFlag.HIDE_ENCHANTS,
                       org.bukkit.inventory.ItemFlag.HIDE_ATTRIBUTES);
        i.setItemMeta(m);
        return i;
    }

    private void playClick(Player p) {
        p.playSound(p.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 1f, 1f);
    }

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    /** InventoryHolder marker for the settings GUI */
    public static class SettingsHolder implements InventoryHolder {
        @Override public Inventory getInventory() { return null; }
    }
}
